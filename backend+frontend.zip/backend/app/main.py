import os
from http.client import HTTPException

from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter, staticfiles
from starlette.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
from .db import init_db
from .routers.sites import router as sites_router
from .routers.units import router as units_router
from .routers.tasks import router as tasks_router
from .routers.inventory import router as inventory_router
from .routers.task_io import router as task_io_router
from .routers.summary import router as summary_router
from .routers.maintenance import router as maintenance_router

if os.getenv("ENV", "development") != "production":
    load_dotenv()            # or load_dotenv(override=False)

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield  # teardown if needed

app = FastAPI(
    title="Rental Ops API",
    docs_url="/api/docs",             # 👈 move docs under /api
    openapi_url="/api/openapi.json",  # 👈 move schema under /api
)


# mount all feature routers under /api
api = APIRouter(prefix="/api")
app.include_router(sites_router)
app.include_router(units_router)
app.include_router(tasks_router)
app.include_router(inventory_router)
app.include_router(summary_router)
app.include_router(maintenance_router)
app.include_router(api)

app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

# Serve SPA (built Vite files) from /frontend/dist
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend", "dist")
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")

# Optional: explicit fallback for any non-/api path, helpful for client-side routes
@app.get("/{full_path:path}")
def spa_fallback(full_path: str):
    # let API routes 404 normally; only fallback non-api to index.html
    if full_path.startswith("api"):
        raise HTTPException(status_code=404, detail="Not Found")
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))